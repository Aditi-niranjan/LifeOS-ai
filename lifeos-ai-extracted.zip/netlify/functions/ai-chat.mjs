export default async (request) => {
  if (request.method !== 'POST') return Response.json({ error: 'Use POST for chat requests.' }, { status: 405 });
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return Response.json({ error: 'AI is not configured yet. Add OPENAI_API_KEY in Netlify environment variables and redeploy.' }, { status: 503 });
  try {
    const body = await request.json();
    const messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
    if (!messages.length || messages.some(m => !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string')) {
      return Response.json({ error: 'Please send a valid conversation.' }, { status: 400 });
    }
    const safeMessages = messages.map(m => ({ role: m.role, content: m.content.slice(0, 6000) }));
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4.1-mini', messages: [
        { role: 'system', content: 'You are LifeOS AI, a practical and kind personal planning assistant. Be clear, realistic, age-appropriate, and nonjudgmental. Do not claim to have changed a user schedule or saved data. Distinguish assumptions from facts. For high-stakes medical, legal, or financial matters, provide general information and encourage consulting a qualified professional or trusted adult when appropriate. Keep answers concise and actionable.' },
        ...safeMessages
      ], temperature: 0.6, max_tokens: 900 })
    });
    const data = await response.json();
    if (!response.ok) return Response.json({ error: data?.error?.message || 'The AI provider could not complete this request.' }, { status: response.status >= 500 ? 502 : response.status });
    return Response.json({ reply: data.choices?.[0]?.message?.content || 'I could not create a response this time.' });
  } catch { return Response.json({ error: 'Something went wrong while contacting the AI service.' }, { status: 500 }); }
};
